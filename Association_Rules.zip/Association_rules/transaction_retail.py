# -*- coding: utf-8 -*-
"""
Created on Sun May  3 21:38:31 2026

@author: lenovo
"""

# ==========================================
# 1. Import Libraries
# ==========================================
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules


# ==========================================
# 2. Load Dataset
# ==========================================
df = pd.read_csv("E:/Aigenius_Class/transactions_retail1.csv", header=None)

print("===== RAW DATA =====")
print(df.head())


# ==========================================
# 3. Convert to Transactions
# ==========================================
transactions = []

for i in range(len(df)):
    row = []
    for item in df.iloc[i]:
        if pd.notna(item):
            row.append(str(item))   # convert to string
    transactions.append(row)

print("\nSample Transactions:")
print(transactions[:5])


# ==========================================
# 4. Apply TransactionEncoder
# ==========================================
te = TransactionEncoder()
te_array = te.fit(transactions).transform(transactions)

df_encoded = pd.DataFrame(te_array, columns=te.columns_)

print("\n===== ENCODED DATA =====")
print(df_encoded.head())


# ==========================================
# 5. Apply Apriori Algorithm
# ==========================================
frequent_itemsets = apriori(
    df_encoded,
    min_support=0.02,   # adjust if needed
    use_colnames=True
)

print("\n===== FREQUENT ITEMSETS =====")
print(frequent_itemsets)


# ==========================================
# 6. Generate Association Rules
# ==========================================
rules = association_rules(
    frequent_itemsets,
    metric="lift",
    min_threshold=1
)

print("\n===== ALL RULES =====")
print(rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])


# ==========================================
# 7. Filter Strong Rules
# ==========================================
strong_rules = rules[
    (rules['confidence'] > 0.3) &
    (rules['lift'] > 1)
]

print("\n===== STRONG RULES =====")
print(strong_rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])


# ==========================================
# 8. Top 10 Rules
# ==========================================
top_rules = rules.sort_values(by='lift', ascending=False).head(10)

print("\n===== TOP 10 RULES =====")
print(top_rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])


# ==========================================
# 9. Visualization
# ==========================================

# Support vs Confidence
plt.figure()
plt.scatter(rules['support'], rules['confidence'])
plt.xlabel("Support")
plt.ylabel("Confidence")
plt.title("Support vs Confidence")
plt.show()


# Lift Distribution
plt.figure()
plt.hist(rules['lift'], bins=20)
plt.title("Lift Distribution")
plt.xlabel("Lift")
plt.ylabel("Frequency")
plt.show()


# ==========================================
# 10. Save Output
# ==========================================
rules.to_csv("association_rules_retail.csv", index=False)
print("\nRules saved successfully!")


##############

sns.countplot(x = 'sex',hue='Salary',data=salary)
plt.show()

#inference:
    
sns.countplot(y='occupation',data=salary)
plt.show()

#Inference:
#Professional and white collar occupations are more common.
#Income levels vary significantly 

#DATA PREPROCESSING FOR SALARY CLASSIFICATION DATASET

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib as plt

from sklearn.preprocessing import StandardScaler,MinMaxScaler,LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.feature_selection import VarianceThreshold
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE

#Load Dataset
df = pd.read_csv("E:/Aigenius_Class/SalaryData_Train.csv")
 

#############
df.drop_duplicates

#########
from col on num_cols:
    sns.boxplot(x=df[col])
    plt.title(col)
    plt.show()
    
#inference:
    #capital gain and capital loss show exterme outliers
    #age and hoursperweek show mild skewness
    
#Winsorization (Outlier treatment)
from feature_engine.outliers import Winsorizer

winsor = Winsorizer(
    capping_method='iqr',
    tail='both',
    fold=1.5,
    variable=['age','hoursperweek',educationno]
)
df[['age','hoursperweek','eduactionno']]=winsor.fit_transform(
    df[['age','hoursperweek','educationno']]
)
sns.boxplot(df.age)

#inference

le = LabelEncoder()
df['Salary'] = le.fit_transform(df['Salary'])

#inference:
# <=50k-> 0, >50k ->1
#required for machine learning algorithm.

#one-hot encoding categorical features

df_encoded = pd.get_dummies(df,drop_first=True)
print("Shape after encoding:",df_encoded.shape)

#inference:
    #converts ctegorical variables into numeric format.
    #drop_first=True avoids dummy variable trap

#EDA
# ==========================================
# EDA FOR RETAIL DATASET
# ==========================================

import pandas as pd
import matplotlib.pyplot as plt
from collections import Counter

# Load Dataset
df = pd.read_csv("E:/Aigenius_Class/SalaryData_Train.csv",header=None)

# Basic Information
print("Shape:", df.shape)

print("\nFirst 5 Rows:")
print(df.head())

# Convert Transactions
transactions = []

for i in range(len(df)):
    for item in df.iloc[i]:
        if pd.notna(item):
            transactions.append(str(item))

# Count Item Frequency
item_counts = Counter(transactions)

# Convert to DataFrame
item_df = pd.DataFrame(
    item_counts.items(),
    columns=['Item', 'Count']
)

# Sort Values
item_df = item_df.sort_values(
    by='Count',
    ascending=False
)

print("\nTop Products:")
print(item_df.head(10))

# Visualization
plt.figure(figsize=(10,5))

plt.bar(
    item_df['Item'].head(10),
    item_df['Count'].head(10)
)

plt.xticks(rotation=45)

plt.title("Top Retail Products")
plt.xlabel("Products")
plt.ylabel("Frequency")

plt.show()    

#data preprocessing 
# ==========================================
# DATA PREPROCESSING FOR RETAIL DATASET
# ==========================================

import pandas as pd
from mlxtend.preprocessing import TransactionEncoder

# Load Dataset
df = pd.read_csv(
    "E:/Aigenius_Class/SalaryData_Train.csv",
    header=None
)

# Display First 5 Rows
print("First 5 Rows:")
print(df.head())

# Convert Transactions into List
transactions = []

for i in range(len(df)):
    
    row = []
    
    for item in df.iloc[i]:
        
        if pd.notna(item):
            row.append(str(item))
    
    transactions.append(row)

# Apply TransactionEncoder
te = TransactionEncoder()

te_array = te.fit(transactions).transform(transactions)

# Convert into DataFrame
df_encoded = pd.DataFrame(
    te_array,
    columns=te.columns_
)

# Final Processed Data
print("\nProcessed Data:")
print(df_encoded.head())

print("\nShape After Preprocessing:")
print(df_encoded.shape)
