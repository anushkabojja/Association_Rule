# -*- coding: utf-8 -*-
"""
Created on Sun May  3 21:35:31 2026

@author: lenovo
"""

# ==========================================
# 1. Import Libraries
# ==========================================
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from mlxtend.frequent_patterns import apriori, association_rules


# ==========================================
# 2. Load Dataset
# ==========================================
df = pd.read_csv("E:/Aigenius_Class/myphonedata.csv")

print("===== RAW DATA =====")
print(df.head())
print("\nShape:", df.shape)


# ==========================================
# 3. Data Preprocessing (SMART HANDLING)
# ==========================================

# Convert Yes/No → 1/0 (if present)
df = df.replace({
    'Yes': 1, 'No': 0,
    'yes': 1, 'no': 0,
    'Y': 1, 'N': 0
})

# Convert everything to numeric safely
df = df.apply(pd.to_numeric, errors='coerce')

# Replace NaN with 0
df = df.fillna(0)

# Convert to boolean
df = df.astype(bool)

print("\n===== PROCESSED DATA =====")
print(df.head())


# ==========================================
# 4. Apply Apriori Algorithm
# ==========================================
frequent_itemsets = apriori(
    df,
    min_support=0.1,   # adjust if needed
    use_colnames=True
)

print("\n===== FREQUENT ITEMSETS =====")
print(frequent_itemsets)


# ==========================================
# 5. Generate Association Rules
# ==========================================
rules = association_rules(
    frequent_itemsets,
    metric="lift",
    min_threshold=1
)

print("\n===== ALL RULES =====")
print(rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])


# ==========================================
# 6. Filter Strong Rules
# ==========================================
strong_rules = rules[
    (rules['confidence'] > 0.5) &
    (rules['lift'] > 1)
]

print("\n===== STRONG RULES =====")
print(strong_rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])


# ==========================================
# 7. Top 10 Rules
# ==========================================
top_rules = rules.sort_values(by='lift', ascending=False).head(10)

print("\n===== TOP 10 RULES =====")
print(top_rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])


# ==========================================
# 8. Visualization
# ==========================================

# Support vs Confidence
plt.figure()
plt.scatter(rules['support'], rules['confidence'])
plt.xlabel("Support")
plt.ylabel("Confidence")
plt.title("Support vs Confidence")
plt.show()


# Lift Distribution
plt.figure()
plt.hist(rules['lift'], bins=20)
plt.title("Lift Distribution")
plt.xlabel("Lift")
plt.ylabel("Frequency")
plt.show()


# ==========================================
# 9. Save Output
# ==========================================
rules.to_csv("association_rules_myphone.csv", index=False)
print("\nRules saved successfully!")

#EDA
# ==========================================
# EDA FOR MOBILE PHONE DATASET
# ==========================================

import pandas as pd
import matplotlib.pyplot as plt

# Load Dataset
df = pd.read_csv("E:/Aigenius_Class/myphonedata.csv")

# Basic Information
print("Shape:", df.shape)

print("\nColumns:")
print(df.columns)

print("\nData Types:")
print(df.dtypes)

print("\nFirst 5 Rows:")
print(df.head())

# Missing Values
print("\nMissing Values:")
print(df.isnull().sum())

# Replace Yes/No
df = df.replace({
    'Yes':1,
    'No':0,
    'yes':1,
    'no':0
})

# Convert Numeric
df = df.apply(pd.to_numeric, errors='coerce')

# Fill NaN
df = df.fillna(0)

# Feature Frequency
feature_freq = df.sum().sort_values(
    ascending=False
)

print("\nFeature Frequency:")
print(feature_freq)

# Visualization
plt.figure(figsize=(10,5))

feature_freq.plot(kind='bar')

plt.title("Mobile Feature Frequency")
plt.xlabel("Features")
plt.ylabel("Frequency")

plt.show()

#data Preprocessing 
# ==========================================
# DATA PREPROCESSING FOR MOBILE PHONE DATASET
# ==========================================

import pandas as pd

# Load Dataset
df = pd.read_csv("E:/Aigenius_Class/myphonedata.csv")

# Display First 5 Rows
print("First 5 Rows:")
print(df.head())

# Check Missing Values
print("\nMissing Values:")
print(df.isnull().sum())

# Replace Yes/No Values
df = df.replace({
    'Yes':1,
    'No':0,
    'yes':1,
    'no':0,
    'Y':1,
    'N':0
})

# Convert into Numeric
df = df.apply(pd.to_numeric, errors='coerce')

# Fill Missing Values
df = df.fillna(0)

# Remove Duplicate Rows
df = df.drop_duplicates()

# Convert into Boolean Format
df = df.astype(bool)

# Final Processed Data
print("\nProcessed Data:")
print(df.head())

print("\nShape After Preprocessing:")
print(df.shape)
