# -*- coding: utf-8 -*-
"""
Created on Sun May  3 21:23:43 2026

@author: lenovo
"""


# ==============================
# 1. Import Libraries
# ==============================
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules


# ==============================
# 2. Load Dataset
# ==============================
df = pd.read_csv("E:/Aigenius_Class/groceries.csv", header=None)

print("Raw Data:")
print(df.head())


# ==============================
# 3. Convert to Transactions
# ==============================
transactions = []

for i in range(len(df)):
    row = []
    for item in df.iloc[i]:
        if pd.notna(item):
            row.append(str(item))   # convert to string
    transactions.append(row)

print("\nSample Transactions:")
print(transactions[:5])


# ==============================
# 4. Apply TransactionEncoder
# ==============================
te = TransactionEncoder()
te_array = te.fit(transactions).transform(transactions)

df_encoded = pd.DataFrame(te_array, columns=te.columns_)

print("\nEncoded Data:")
print(df_encoded.head())


# ==============================
# 5. Apply Apriori Algorithm
# ==============================
frequent_itemsets = apriori(df_encoded, min_support=0.02, use_colnames=True)

print("\nFrequent Itemsets:")
print(frequent_itemsets.head())


# ==============================
# 6. Generate Association Rules
# ==============================
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1)

print("\nAssociation Rules:")
print(rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])


# ==============================
# 7. Top 10 Rules
# ==============================
top_rules = rules.sort_values(by='lift', ascending=False).head(10)

print("\nTop 10 Rules:")
print(top_rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])

#EDA
# ==========================================
# EDA FOR GROCERIES DATASET
# ==========================================

import pandas as pd
import matplotlib.pyplot as plt
from collections import Counter

# Load Dataset
df = pd.read_csv("E:/Aigenius_Class/groceries.csv", header=None)

# Basic Information
print("Shape:", df.shape)

print("\nFirst 5 Rows:")
print(df.head())

# Convert Transactions
transactions = []

for i in range(len(df)):
    for item in df.iloc[i]:
        if pd.notna(item):
            transactions.append(str(item))

# Count Frequencies
item_counts = Counter(transactions)

# Convert to DataFrame
item_df = pd.DataFrame(
    item_counts.items(),
    columns=['Item', 'Count']
)

# Sort Values
item_df = item_df.sort_values(
    by='Count',
    ascending=False
)

print("\nTop Items:")
print(item_df.head(10))

# Visualization
plt.figure(figsize=(10,5))

plt.bar(
    item_df['Item'].head(10),
    item_df['Count'].head(10)
)

plt.xticks(rotation=45)

plt.title("Top Grocery Items")
plt.xlabel("Items")
plt.ylabel("Frequency")

plt.show()

#data preprocessing 
# ==========================================
# DATA PREPROCESSING FOR GROCERIES DATASET
# ==========================================

import pandas as pd
from mlxtend.preprocessing import TransactionEncoder

# Load Dataset
df = pd.read_csv("E:/Aigenius_Class/groceries.csv", header=None)

# Display First 5 Rows
print("First 5 Rows:")
print(df.head())

# Convert Transactions into List
transactions = []

for i in range(len(df)):
    row = []
    
    for item in df.iloc[i]:
        if pd.notna(item):
            row.append(str(item))
    
    transactions.append(row)

# Apply TransactionEncoder
te = TransactionEncoder()

te_array = te.fit(transactions).transform(transactions)

# Convert into DataFrame
df_encoded = pd.DataFrame(
    te_array,
    columns=te.columns_
)

# Final Processed Data
print("\nProcessed Data:")
print(df_encoded.head())

print("\nShape After Preprocessing:")
print(df_encoded.shape)
