# -*- coding: utf-8 -*-
"""
Created on Sun May  3 21:29:34 2026

@author: lenovo
"""

# ==========================================
# 1. Import Libraries
# ==========================================
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from mlxtend.frequent_patterns import apriori, association_rules


# ==========================================
# 2. Load Dataset
# ==========================================
df = pd.read_csv("E:/Aigenius_Class/my_movies.csv")

print("===== RAW DATA =====")
print(df.head())
print("\nShape:", df.shape)


# ==========================================
# 3. Data Preprocessing
# ==========================================

# If dataset already has 0/1 → just convert to boolean
df = df.astype(bool)

# If your dataset has Yes/No instead, use this instead:
# df = df.replace({'Yes':1, 'No':0}).astype(bool)

print("\n===== PROCESSED DATA =====")
print(df.head())


# ==========================================
# 4. Apply Apriori Algorithm
# ==========================================
frequent_itemsets = apriori(
    df,
    min_support=0.1,      # adjust if needed
    use_colnames=True
)

print("\n===== FREQUENT ITEMSETS =====")
print(frequent_itemsets)


# ==========================================
# 5. Generate Association Rules
# ==========================================
rules = association_rules(
    frequent_itemsets,
    metric="lift",
    min_threshold=1
)

print("\n===== ALL RULES =====")
print(rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])


# ==========================================
# 6. Filter Strong Rules
# ==========================================
strong_rules = rules[
    (rules['confidence'] > 0.5) &
    (rules['lift'] > 1)
]

print("\n===== STRONG RULES =====")
print(strong_rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])


# ==========================================
# 7. Top 10 Rules
# ==========================================
top_rules = rules.sort_values(by='lift', ascending=False).head(10)

print("\n===== TOP 10 RULES =====")
print(top_rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])


# ==========================================
# 8. Visualization
# ==========================================

# Support vs Confidence
plt.figure()
plt.scatter(rules['support'], rules['confidence'])
plt.xlabel("Support")
plt.ylabel("Confidence")
plt.title("Support vs Confidence")
plt.show()


# Lift Distribution
plt.figure()
plt.hist(rules['lift'], bins=20)
plt.title("Lift Distribution")
plt.xlabel("Lift")
plt.ylabel("Frequency")
plt.show()


# ==========================================
# 9. Save Results (Optional)
# ==========================================
rules.to_csv("association_rules_movies.csv", index=False)
print("\nRules saved to association_rules_movies.csv")

#EDA
# ==========================================
# EDA FOR MOVIES DATASET
# ==========================================

import pandas as pd
import matplotlib.pyplot as plt

# Load Dataset
df = pd.read_csv("E:/Aigenius_Class/my_movies.csv")

# Basic Information
print("Shape:", df.shape)

print("\nColumns:")
print(df.columns)

print("\nData Types:")
print(df.dtypes)

print("\nFirst 5 Rows:")
print(df.head())

# Missing Values
print("\nMissing Values:")
print(df.isnull().sum())

# Frequency Count
movie_frequency = df.sum().sort_values(
    ascending=False
)

print("\nMovie Frequency:")
print(movie_frequency)

# Visualization
plt.figure(figsize=(10,5))

movie_frequency.plot(kind='bar')

plt.title("Movie Frequency")
plt.xlabel("Movies")
plt.ylabel("Count")

plt.show()

#Data Preprocessing
# ==========================================
# DATA PREPROCESSING FOR MOVIES DATASET
# ==========================================

import pandas as pd

# Load Dataset
df = pd.read_csv("E:/Aigenius_Class/my_movies.csv")

# Display First 5 Rows
print("First 5 Rows:")
print(df.head())

# Check Missing Values
print("\nMissing Values:")
print(df.isnull().sum())

# Remove Duplicate Rows
df = df.drop_duplicates()

# Convert to Boolean Format
df = df.astype(bool)

# Final Processed Data
print("\nProcessed Data:")
print(df.head())

print("\nShape After Preprocessing:")
print(df.shape)
