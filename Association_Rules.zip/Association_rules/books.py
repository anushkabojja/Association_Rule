# -*- coding: utf-8 -*-
"""
Created on Sun May  3 11:27:36 2026

@author: lenovo
"""
#"E:/Aigenius_Class/book.csv"
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from mlxtend.frequent_patterns import apriori, association_rules
from mlxtend.preprocessing import TransactionEncoder

df = pd.read_csv("E:/Aigenius_Class/book.csv")
print(df.head())

# Convert values to boolean
df = df.astype(bool)

frequent_itemsets = apriori(df, min_support=0.1, use_colnames=True)

print(frequent_itemsets.head())

rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1)

print(rules.head())

strong_rules = rules[
    (rules['lift'] > 1) &
    (rules['confidence'] > 0.5)
]

print(strong_rules)

plt.figure(figsize=(8,6))
sns.scatterplot(
    x=rules['support'],
    y=rules['confidence'],
    size=rules['lift'],
    hue=rules['lift']
)
plt.title("Support vs Confidence")
plt.show()

plt.figure(figsize=(6,4))
sns.histplot(rules['lift'], bins=20)
plt.title("Lift Distribution")
plt.show()

top_rules = rules.sort_values(by='lift', ascending=False).head(10)
print(top_rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])

#EDA
# ==========================================
# EDA FOR BOOKS DATASET
# ==========================================

import pandas as pd
import matplotlib.pyplot as plt

# Load Dataset
df = pd.read_csv("E:/Aigenius_Class/book.csv")

# Basic Information
print("Shape:", df.shape)

print("\nColumns:")
print(df.columns)

print("\nData Types:")
print(df.dtypes)

print("\nFirst 5 Rows:")
print(df.head())

# Missing Values
print("\nMissing Values:")
print(df.isnull().sum())

# Statistical Summary
print("\nSummary:")
print(df.describe())

# Frequency Count
book_frequency = df.sum().sort_values(ascending=False)

print("\nBook Frequency:")
print(book_frequency)

# Visualization
plt.figure(figsize=(10,5))
book_frequency.head(10).plot(kind='bar')

plt.title("Top 10 Books")
plt.xlabel("Books")
plt.ylabel("Frequency")

plt.show()

#data preprocessing 
# ==========================================
# DATA PREPROCESSING FOR BOOKS DATASET
# ==========================================

import pandas as pd

# Load Dataset
df = pd.read_csv("E:/Aigenius_Class/book.csv")

# Display First 5 Rows
print("First 5 Rows:")
print(df.head())

# Check Missing Values
print("\nMissing Values:")
print(df.isnull().sum())

# Remove Duplicate Rows
df = df.drop_duplicates()

# Convert Data into Boolean Format
df = df.astype(bool)

# Final Information
print("\nProcessed Data:")
print(df.head())

print("\nShape After Preprocessing:")
print(df.shape)
